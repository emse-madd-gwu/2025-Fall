# This file is just a demonstration of how to make the choice_questions.csv
# file in the root folder. You'll need to make your own survey design 
# according to the context of your experiment

# Install packages
# install.packages("fastDummies")
# install.packages("cbcTools")

# Load libraries
library(cbcTools)
library(fastDummies)
library(tidyverse)

# Define profiles with attributes and levels
profiles <- cbc_profiles(
    price     = seq(1, 4, 0.5), # $ per pound 
    type      = c('Fuji', 'Gala', 'Honeycrisp', 'Pink Lady', 'Red Delicious'),
    freshness = c('Poor', 'Average', 'Excellent')
)

# Make a full-factorial design of experiment 
design <- cbc_design(
    profiles = profiles,
    n_resp   = 1000, # Number of respondents
    n_alts   = 3,    # Number of alternatives per question
    n_q      = 8     # Number of questions per respondent
)

head(design) # preview


# For this particular experiment, I include images of the apples in the 
# choice questions:

image_names <- data.frame(
    type = c('Fuji', 'Gala', 'Honeycrisp', 'Pink Lady', 'Red Delicious'),
    image = c('fuji.jpg', 'gala.jpg', 'honeycrisp.jpg', 'pinkLady.jpg', 
          'redDelicious.jpg')
)
design <- design %>% 
    left_join(image_names, by = "type")
head(design) # preview

# Save design
write_csv(design, 'choice_questions.csv')
